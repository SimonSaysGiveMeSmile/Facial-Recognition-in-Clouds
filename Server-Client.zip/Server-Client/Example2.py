import socket

# Define the host and port number
HOST, PORT = 'localhost', 8000
# Create a socket object using the default settings
with socket.socket() as client_socket:
    # Connect to the server
    client_socket.connect((HOST, PORT))
    # To indicate that the client has connected
    print(f"Connected to server at {HOST}:{PORT}")
    # Send a message to the server
    client_socket.sendall(b"Hello from the client!")
    # Receive a response from the server
    data = client_socket.recv(1024)
    # Print the response received from the server
    print(f"Received data: {data.decode()}")
    
    