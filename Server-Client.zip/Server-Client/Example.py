import socket

# Define the host and port number
HOST, PORT = '', 8000
# Create a socket object 
with socket.socket() as server_socket:
    # Bind the socket to a specific address & port
    server_socket.bind((HOST, PORT))
    # Listen for incoming connections
    server_socket.listen()
    # To indicate that the server is ready
    print(f"Server is listening on {HOST}:{PORT}")
    
    # Wait for connections and handle arrivals
    while True:
        # Accept a connection and make a new object
        conn, addr = server_socket.accept()
        # To indicate that a client has connected
        print(f"Client connected from {addr}")
        # Receive data from the client
        data = conn.recv(1024)
        # Print the data received from the client
        print(f"Received data: {data.decode()}")
        # Send a response back to the client
        conn.sendall(b"Hello from the server!")
        
        