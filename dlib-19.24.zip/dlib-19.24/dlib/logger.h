// Copyright (C) 2006  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_LOGGEr_
#define DLIB_LOGGEr_

#include "logger/logger_kernel_1.h"
#include "logger/extra_logger_headers.h"
#include "logger/logger_config_file.h"

#endif // DLIB_LOGGEr_ 

